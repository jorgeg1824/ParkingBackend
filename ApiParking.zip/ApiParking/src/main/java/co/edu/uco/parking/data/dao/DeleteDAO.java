package co.edu.uco.parking.data.dao;

public interface DeleteDAO<ID> {
	void delete(ID id);
}
