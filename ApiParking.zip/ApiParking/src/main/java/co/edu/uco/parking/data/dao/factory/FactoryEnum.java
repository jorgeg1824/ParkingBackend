package co.edu.uco.parking.data.dao.factory;

enum FactoryEnum {
	MYSQL, 
	ORACLE, 
	POSTGRESQL, 
	SQLSERVER
}

