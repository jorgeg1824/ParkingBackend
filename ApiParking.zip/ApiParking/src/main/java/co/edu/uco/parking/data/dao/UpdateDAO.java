package co.edu.uco.parking.data.dao;

public interface UpdateDAO<E> {
	void update(E entity);
}
