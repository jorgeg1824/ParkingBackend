package co.edu.uco.parking.business.business.rule;

public interface Rule {
	
	void execute(Object... data);

}
