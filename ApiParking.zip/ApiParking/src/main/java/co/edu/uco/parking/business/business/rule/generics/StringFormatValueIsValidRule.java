package co.edu.uco.parking.business.business.rule.generics;

public class StringFormatValueIsValidRule {

}
