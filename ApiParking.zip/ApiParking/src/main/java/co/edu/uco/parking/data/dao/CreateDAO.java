package co.edu.uco.parking.data.dao;

public interface CreateDAO<E> {
	void create(E entity);
}
